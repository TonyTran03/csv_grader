CSV Health Checker
------------------
Unzip the folder, and upload the entire folder containing csv (eg. farm)